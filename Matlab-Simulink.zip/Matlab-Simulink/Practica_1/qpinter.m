function [pr,qr] = qpinter(P1, P2, t)
    % Posición
    p1 = P1(1:3,4);
    p2 = P2(1:3,4);
    lambda = t; % Asumimos t ∈ [0,1]
    pr = p1 + lambda * (p2 - p1);

    % Cuaterniones
    q1 = tr2q(P1);
    q2 = tr2q(P2);
    q1 = q1 / norm(q1);
    q2 = q2 / norm(q2);

    % Asegura el camino corto
if dot(q1, q2) < 0
    q2 = -q2;
end
    inv_q1 = [q1(1), -q1(2:4)];
    q = qqmul(inv_q1, q2);

    theta = 2 * acos(q(1));
    if abs(sin(theta/2)) < 1e-6
        u = [0 0 0];
    else
        u = q(2:4) / sin(theta / 2);
    end

    q_giro = [cos(lambda * theta / 2), u * sin(lambda * theta / 2)];
    qr = qqmul(q1, q_giro);
end
