function [P, Q] = generate_smooth_path(P0, P1, P2, tau, T, t)
    % Calcula la posición P (1x3) y orientación Q (cuaternión [w x y z])
    % suavizando la trayectoria entre P0, P1 y P2 usando el método de Taylor

    % Extraer posiciones y cuaterniones
    p0 = P0(1:3,4)';
    p1 = P1(1:3,4)';
    p2 = P2(1:3,4)';

    q0 = tr2q(P0);
    q1 = tr2q(P1);
    q2 = tr2q(P2);

    % Normalizar cuaterniones
    q0 = q0 / norm(q0);
    q1 = q1 / norm(q1);
    q2 = q2 / norm(q2);

    dP1 = p1 - p0;
    dP2 = p2 - p1;

    if (t < -T || t > T)
        disp('Parameter t out of range');
        P = [NaN NaN NaN];
        Q = [1 0 0 0];
        return;
    end

    if (t <= -tau)
        % Primer segmento: P0 → P1 (lineal)
        %lambda = (t + T) / (T - tau);
        lambda = (t + T) /T;
        lambda = max(0, min(1, lambda));  % Asegurar que lambda ∈ [0,1]
        [P, Q] = qpinter(P0, P1, lambda);

    elseif (t >= tau)
        % Tercer segmento: P1 → P2 (lineal)
        %lambda2 = (t - tau) / (T - tau);
        lambda2 = (t) / (T);
        lambda2 = max(0, min(1, lambda2));
        [P, Q] = qpinter(P1, P2, lambda2);

    else
        % Segmento intermedio (suavizado entre P0, P1, P2)

        % Posición (Taylor)
        P = p1 - dP1 * (tau - t)^2 / (4 * tau * T) + dP2 * (tau + t)^2 / (4 * tau * T);

        % Orientación (Taylor con cuaterniones)
        inv_q0 = [q0(1), -q0(2:4)];
        inv_q1 = [q1(1), -q1(2:4)];

        q_rot1 = qqmul(inv_q0, q1);
        q_rot2 = qqmul(inv_q1, q2);

        % Extraer ángulos y ejes de rotación
        theta1 = 2 * acos(min(max(q_rot1(1), -1), 1));
        theta2 = 2 * acos(min(max(q_rot2(1), -1), 1));

        if abs(sin(theta1/2)) < 1e-6
            u1 = [0 0 0];
        else
            u1 = q_rot1(2:4) / sin(theta1 / 2);
        end

        if abs(sin(theta2/2)) < 1e-6
            u2 = [0 0 0];
        else
            u2 = q_rot2(2:4) / sin(theta2 / 2);
        end

        angulo1 = -theta1 * (tau - t)^2 / (4 * tau * T);
        angulo2 =  theta2 * (tau + t)^2 / (4 * tau * T);

        q_giro1 = [cos(angulo1/2), u1 * sin(angulo1/2)];
        q_giro2 = [cos(angulo2/2), u2 * sin(angulo2/2)];

        q = qqmul(qqmul(q1, q_giro1), q_giro2);
        Q = q / norm(q);
    end
end
